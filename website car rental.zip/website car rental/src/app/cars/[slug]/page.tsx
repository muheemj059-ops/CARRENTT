import Link from "next/link";
import Image from "next/image";
import { notFound } from "next/navigation";
import { cars, getCarBySlug } from "@/lib/cars";
import { formatPKR } from "@/lib/site";

type Props = {
  params: Promise<{ slug: string }>;
};

export function generateStaticParams() {
  return cars.map((c) => ({ slug: c.slug }));
}

export default async function CarDetailPage({ params }: Props) {
  const { slug } = await params;
  const car = getCarBySlug(slug);
  if (!car) notFound();

  return (
    <main className="mx-auto w-full max-w-6xl px-4 py-10">
      <div className="flex flex-col gap-2">
        <div className="text-sm text-black/60 dark:text-white/60">
          <Link
            href="/fleet"
            className="underline underline-offset-4 hover:no-underline"
          >
            Fleet
          </Link>{" "}
          / {car.name}
        </div>
        <h1 className="text-3xl font-semibold tracking-tight">{car.name}</h1>
        <div className="text-sm text-black/70 dark:text-white/70">
          {car.category} · {car.ac ? "AC" : "No AC"} · {car.transmission} ·{" "}
          {car.seats} seats · {car.fuel}
        </div>
      </div>

      <div className="mt-7 grid gap-6 lg:grid-cols-3">
        <section className="rounded-3xl border border-black/10 bg-white p-6 dark:border-white/15 dark:bg-black/20 lg:col-span-2">
          <div className="overflow-hidden rounded-2xl border border-black/10 bg-black/[.03] dark:border-white/15 dark:bg-white/[.06]">
            <div className="relative aspect-[16/9] w-full">
              <Image
                src={car.imageSrc}
                alt={car.imageAlt}
                fill
                className="object-contain p-6"
                priority
              />
            </div>
          </div>

          <div className="grid gap-6 md:grid-cols-2">
            <div className="rounded-2xl border border-black/10 bg-gradient-to-b from-black/[.04] to-transparent p-5 dark:border-white/15 dark:from-white/[.06]">
              <div className="text-sm font-semibold">Rates (indicative)</div>
              <div className="mt-3 grid gap-3">
                <div className="flex items-baseline justify-between">
                  <div className="text-sm text-black/70 dark:text-white/70">
                    Daily from
                  </div>
                  <div className="text-lg font-semibold">
                    {formatPKR(car.dailyFromPKR)}
                  </div>
                </div>
                <div className="flex items-baseline justify-between">
                  <div className="text-sm text-black/70 dark:text-white/70">
                    Weekly from
                  </div>
                  <div className="text-lg font-semibold">
                    {formatPKR(car.weeklyFromPKR)}
                  </div>
                </div>
              </div>
              <div className="mt-3 text-xs text-black/60 dark:text-white/60">
                Final quote depends on city, dates, duration and availability.
              </div>
            </div>

            <div className="rounded-2xl border border-black/10 bg-white p-5 dark:border-white/15 dark:bg-black/20">
              <div className="text-sm font-semibold">Availability</div>
              <div className="mt-3 flex flex-wrap gap-2">
                {car.cityAvailability.map((c) => (
                  <span
                    key={c}
                    className="rounded-full border border-black/10 px-3 py-1 text-xs text-black/70 dark:border-white/15 dark:text-white/70"
                  >
                    {c}
                  </span>
                ))}
              </div>
            </div>
          </div>

          <div className="mt-6 grid gap-6 md:grid-cols-2">
            <div className="rounded-2xl border border-black/10 bg-white p-5 dark:border-white/15 dark:bg-black/20">
              <div className="text-sm font-semibold">Highlights</div>
              <ul className="mt-3 grid list-disc gap-2 pl-5 text-sm text-black/70 dark:text-white/70">
                {car.features.map((f) => (
                  <li key={f}>{f}</li>
                ))}
              </ul>
            </div>

            <div className="rounded-2xl border border-black/10 bg-white p-5 dark:border-white/15 dark:bg-black/20">
              <div className="text-sm font-semibold">Terms</div>
              <ul className="mt-3 grid list-disc gap-2 pl-5 text-sm text-black/70 dark:text-white/70">
                {car.terms.map((t) => (
                  <li key={t}>{t}</li>
                ))}
              </ul>
            </div>
          </div>
        </section>

        <aside className="rounded-3xl border border-black/10 bg-white p-6 dark:border-white/15 dark:bg-black/20">
          <div className="text-sm font-semibold">Request this car</div>
          <p className="mt-2 text-sm text-black/70 dark:text-white/70">
            Share your dates and pickup city to confirm availability.
          </p>

          <div className="mt-5 grid gap-3">
            <Link
              href={`/book?car=${encodeURIComponent(car.name)}`}
              className="inline-flex h-11 items-center justify-center rounded-full bg-black px-5 text-sm font-medium text-white hover:bg-black/90 dark:bg-white dark:text-black dark:hover:bg-white/90"
            >
              Request booking
            </Link>
            <Link
              href="/fleet"
              className="inline-flex h-11 items-center justify-center rounded-full border border-black/10 px-5 text-sm font-medium text-black hover:bg-black/5 dark:border-white/15 dark:text-white dark:hover:bg-white/10"
            >
              Back to fleet
            </Link>
          </div>

          <div className="mt-6 rounded-2xl border border-black/10 bg-black/[.03] p-4 text-sm dark:border-white/15 dark:bg-white/[.06]">
            <div className="font-semibold">Tip</div>
            <div className="mt-1 text-black/70 dark:text-white/70">
              For weekends and holidays, book early to secure your preferred car.
            </div>
          </div>
        </aside>
      </div>
    </main>
  );
}

