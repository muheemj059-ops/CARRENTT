import Link from "next/link";
import { cars, cities } from "@/lib/cars";
import { CarCard } from "@/components/CarCard";

type Props = {
  searchParams?: Promise<Record<string, string | string[] | undefined>>;
};

function getFirst(value: string | string[] | undefined) {
  if (!value) return "";
  return Array.isArray(value) ? value[0] ?? "" : value;
}

export default async function FleetPage({ searchParams }: Props) {
  const sp = (await searchParams) ?? {};
  const q = getFirst(sp.q).trim().toLowerCase();
  const city = getFirst(sp.city).trim();
  const transmission = getFirst(sp.transmission).trim();
  const category = getFirst(sp.category).trim();
  const ac = getFirst(sp.ac).trim();

  const filtered = cars.filter((c) => {
    const matchesQ = !q || c.name.toLowerCase().includes(q);
    const matchesCity = !city || c.cityAvailability.includes(city);
    const matchesTransmission = !transmission || c.transmission === transmission;
    const matchesCategory = !category || c.category === category;
    const matchesAC =
      !ac || (ac === "Yes" ? c.ac === true : ac === "No" ? c.ac === false : true);
    return (
      matchesQ &&
      matchesCity &&
      matchesTransmission &&
      matchesCategory &&
      matchesAC
    );
  });

  return (
    <main className="mx-auto w-full max-w-6xl px-4 py-10">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-semibold tracking-tight">Fleet</h1>
        <p className="text-sm text-black/70 dark:text-white/70">
          Filter by city and transmission. Click a car to see details and request
          booking.
        </p>
      </div>

      <form className="mt-6 grid gap-3 rounded-2xl border border-black/10 bg-white p-4 dark:border-white/15 dark:bg-black/20 md:grid-cols-4">
        <label className="grid gap-1 text-sm">
          <span className="text-black/70 dark:text-white/70">Search</span>
          <input
            name="q"
            defaultValue={getFirst(sp.q)}
            placeholder="Corolla, Alto, Fortuner..."
            className="h-11 rounded-xl border border-black/10 bg-white px-3 outline-none focus:border-black/30 dark:border-white/15 dark:bg-black/20 dark:focus:border-white/40"
          />
        </label>

        <label className="grid gap-1 text-sm">
          <span className="text-black/70 dark:text-white/70">City</span>
          <select
            name="city"
            defaultValue={city}
            className="h-11 rounded-xl border border-black/10 bg-white px-3 outline-none focus:border-black/30 dark:border-white/15 dark:bg-black/20 dark:focus:border-white/40"
          >
            <option value="">All cities</option>
            {cities.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </label>

        <label className="grid gap-1 text-sm">
          <span className="text-black/70 dark:text-white/70">Transmission</span>
          <select
            name="transmission"
            defaultValue={transmission}
            className="h-11 rounded-xl border border-black/10 bg-white px-3 outline-none focus:border-black/30 dark:border-white/15 dark:bg-black/20 dark:focus:border-white/40"
          >
            <option value="">Any</option>
            <option value="Automatic">Automatic</option>
            <option value="Manual">Manual</option>
          </select>
        </label>

        <label className="grid gap-1 text-sm">
          <span className="text-black/70 dark:text-white/70">Category</span>
          <select
            name="category"
            defaultValue={category}
            className="h-11 rounded-xl border border-black/10 bg-white px-3 outline-none focus:border-black/30 dark:border-white/15 dark:bg-black/20 dark:focus:border-white/40"
          >
            <option value="">Any</option>
            <option value="Economy">Economy</option>
            <option value="Standard">Standard</option>
            <option value="SUV">SUV</option>
            <option value="Luxury">Luxury</option>
            <option value="Van">Van</option>
          </select>
        </label>

        <label className="grid gap-1 text-sm">
          <span className="text-black/70 dark:text-white/70">AC</span>
          <select
            name="ac"
            defaultValue={ac}
            className="h-11 rounded-xl border border-black/10 bg-white px-3 outline-none focus:border-black/30 dark:border-white/15 dark:bg-black/20 dark:focus:border-white/40"
          >
            <option value="">Any</option>
            <option value="Yes">AC</option>
            <option value="No">No AC</option>
          </select>
        </label>

        <div className="flex items-end gap-2 md:col-span-2">
          <button className="inline-flex h-11 flex-1 items-center justify-center rounded-full bg-black px-5 text-sm font-medium text-white hover:bg-black/90 dark:bg-white dark:text-black dark:hover:bg-white/90">
            Apply
          </button>
          <Link
            href="/fleet"
            className="inline-flex h-11 items-center justify-center rounded-full border border-black/10 px-4 text-sm font-medium text-black hover:bg-black/5 dark:border-white/15 dark:text-white dark:hover:bg-white/10"
          >
            Reset
          </Link>
        </div>
      </form>

      <div className="mt-8 flex items-baseline justify-between gap-4">
        <div className="text-sm text-black/70 dark:text-white/70">
          {filtered.length} car{filtered.length === 1 ? "" : "s"} found
        </div>
        <Link
          href="/book"
          className="text-sm font-medium text-black/70 hover:text-black dark:text-white/70 dark:hover:text-white"
        >
          Request booking →
        </Link>
      </div>

      <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {filtered.map((car) => (
          <CarCard key={car.slug} car={car} />
        ))}
      </div>
    </main>
  );
}

