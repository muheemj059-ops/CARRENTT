import { BookingForm } from "@/components/BookingForm";
import { site } from "@/lib/site";

type Props = {
  searchParams?: Promise<Record<string, string | string[] | undefined>>;
};

function getFirst(value: string | string[] | undefined) {
  if (!value) return "";
  return Array.isArray(value) ? value[0] ?? "" : value;
}

export default async function BookPage({ searchParams }: Props) {
  const sp = (await searchParams) ?? {};
  const car = getFirst(sp.car);

  return (
    <main className="mx-auto w-full max-w-3xl px-4 py-10">
      <h1 className="text-3xl font-semibold tracking-tight">Request a booking</h1>
      <p className="mt-2 text-sm text-black/70 dark:text-white/70">
        Fill in the details and send your request to {site.name} on WhatsApp.
      </p>

      <section className="mt-6 rounded-3xl border border-black/10 bg-white p-6 dark:border-white/15 dark:bg-black/20">
        <BookingForm defaultCar={car} />
      </section>
    </main>
  );
}

