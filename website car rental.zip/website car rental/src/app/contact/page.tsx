import Link from "next/link";
import { site, buildWhatsAppLink } from "@/lib/site";

export default function ContactPage() {
  const quickMessage = buildWhatsAppLink(
    `Hello ${site.name}! I’d like to ask about car rentals in Pakistan.`,
  );

  return (
    <main className="mx-auto w-full max-w-4xl px-4 py-10">
      <h1 className="text-3xl font-semibold tracking-tight">Contact</h1>
      <p className="mt-2 text-sm text-black/70 dark:text-white/70">
        Reach out for availability, airport pickup, or custom quotes.
      </p>

      <div className="mt-6 grid gap-6 md:grid-cols-2">
        <section className="rounded-3xl border border-black/10 bg-white p-6 dark:border-white/15 dark:bg-black/20">
          <div className="text-sm font-semibold">Call / WhatsApp</div>
          <div className="mt-3 space-y-2 text-sm text-black/70 dark:text-white/70">
            <div>
              Phone:{" "}
              <a
                href={`tel:${site.supportPhone}`}
                className="underline underline-offset-4 hover:no-underline"
              >
                {site.supportPhone}
              </a>
            </div>
            <div>
              Email:{" "}
              <a
                href={`mailto:${site.email}`}
                className="underline underline-offset-4 hover:no-underline"
              >
                {site.email}
              </a>
            </div>
            <div>Service cities: {site.cities.join(", ")}</div>
          </div>

          <div className="mt-5 flex flex-col gap-3 sm:flex-row">
            <a
              href={quickMessage}
              target="_blank"
              rel="noreferrer"
              className="inline-flex h-11 flex-1 items-center justify-center rounded-full bg-black px-5 text-sm font-medium text-white hover:bg-black/90 dark:bg-white dark:text-black dark:hover:bg-white/90"
            >
              Message on WhatsApp
            </a>
            <Link
              href="/book"
              className="inline-flex h-11 items-center justify-center rounded-full border border-black/10 px-5 text-sm font-medium text-black hover:bg-black/5 dark:border-white/15 dark:text-white dark:hover:bg-white/10"
            >
              Request booking
            </Link>
          </div>
        </section>

        <section className="rounded-3xl border border-black/10 bg-white p-6 dark:border-white/15 dark:bg-black/20">
          <div className="text-sm font-semibold">Frequently asked</div>
          <div className="mt-4 grid gap-4 text-sm">
            <div className="rounded-2xl border border-black/10 p-4 dark:border-white/15">
              <div className="font-semibold">Do you offer rentals with driver?</div>
              <div className="mt-1 text-black/70 dark:text-white/70">
                Yes — share your route and dates and we’ll confirm driver
                availability and the final quote.
              </div>
            </div>
            <div className="rounded-2xl border border-black/10 p-4 dark:border-white/15">
              <div className="font-semibold">What documents are needed?</div>
              <div className="mt-1 text-black/70 dark:text-white/70">
                Typically CNIC for verification (and license for self-drive where
                applicable).
              </div>
            </div>
            <div className="rounded-2xl border border-black/10 p-4 dark:border-white/15">
              <div className="font-semibold">Airport pickup?</div>
              <div className="mt-1 text-black/70 dark:text-white/70">
                Available in major cities. Send your flight time and terminal via
                the booking page.
              </div>
            </div>
          </div>
        </section>
      </div>
    </main>
  );
}

