"use client";

import { useMemo, useState } from "react";
import { buildWhatsAppLink, site } from "@/lib/site";

type Props = {
  defaultCar?: string;
};

export function BookingForm({ defaultCar = "" }: Props) {
  const [name, setName] = useState<string>("");
  const [phone, setPhone] = useState<string>("");
  const [city, setCity] = useState<string>(site.cities[0] ?? "");
  const [car, setCar] = useState<string>(defaultCar);
  const [pickupDate, setPickupDate] = useState<string>("");
  const [returnDate, setReturnDate] = useState<string>("");
  const [withDriver, setWithDriver] = useState<"Yes" | "No">("No");
  const [notes, setNotes] = useState<string>("");

  const message = useMemo(() => {
    const lines = [
      `Booking request — ${site.name}`,
      "",
      `Name: ${name || "-"}`,
      `Phone: ${phone || "-"}`,
      `City: ${city || "-"}`,
      `Car: ${car || "-"}`,
      `Pickup date: ${pickupDate || "-"}`,
      `Return date: ${returnDate || "-"}`,
      `With driver: ${withDriver}`,
      notes ? `Notes: ${notes}` : "",
    ].filter(Boolean);
    return lines.join("\n");
  }, [car, city, name, notes, phone, pickupDate, returnDate, withDriver]);

  const whatsappHref = useMemo(() => buildWhatsAppLink(message), [message]);

  return (
    <div className="glass-panel p-8 rounded-[2rem] shadow-2xl relative overflow-hidden">
      {/* Decorative gradient blur in background */}
      <div className="absolute top-0 right-0 -mr-20 -mt-20 h-64 w-64 rounded-full bg-primary/10 blur-[80px] pointer-events-none" />

      <h3 className="text-2xl font-bold tracking-tight mb-6">Booking Details</h3>

      <div className="grid gap-5 relative z-10">
        <div className="grid gap-5 md:grid-cols-2">
          <label className="grid gap-1.5 text-sm group">
            <span className="text-black/60 dark:text-white/60 font-medium ml-1 transition-colors group-focus-within:text-primary">Full name</span>
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Your name"
              className="h-12 rounded-xl bg-black/5 dark:bg-white/5 px-4 outline-none border border-transparent transition-all focus:border-primary/50 focus:bg-white dark:focus:bg-black/50 focus:ring-4 focus:ring-primary/10"
            />
          </label>

          <label className="grid gap-1.5 text-sm group">
            <span className="text-black/60 dark:text-white/60 font-medium ml-1 transition-colors group-focus-within:text-primary">Phone (WhatsApp)</span>
            <input
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="+92 3xx xxxxxxx"
              className="h-12 rounded-xl bg-black/5 dark:bg-white/5 px-4 outline-none border border-transparent transition-all focus:border-primary/50 focus:bg-white dark:focus:bg-black/50 focus:ring-4 focus:ring-primary/10"
            />
          </label>

          <label className="grid gap-1.5 text-sm group">
            <span className="text-black/60 dark:text-white/60 font-medium ml-1 transition-colors group-focus-within:text-primary">Pickup city</span>
            <select
              value={city}
              onChange={(e) => setCity(e.target.value)}
              className="h-12 rounded-xl bg-black/5 dark:bg-white/5 px-4 outline-none border border-transparent transition-all focus:border-primary/50 focus:bg-white dark:focus:bg-black/50 focus:ring-4 focus:ring-primary/10 appearance-none cursor-pointer"
            >
              {site.cities.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </label>

          <label className="grid gap-1.5 text-sm group">
            <span className="text-black/60 dark:text-white/60 font-medium ml-1 transition-colors group-focus-within:text-primary">Car (optional)</span>
            <input
              value={car}
              onChange={(e) => setCar(e.target.value)}
              placeholder="e.g., Toyota Corolla (Automatic)"
              className="h-12 rounded-xl bg-black/5 dark:bg-white/5 px-4 outline-none border border-transparent transition-all focus:border-primary/50 focus:bg-white dark:focus:bg-black/50 focus:ring-4 focus:ring-primary/10"
            />
          </label>

          <label className="grid gap-1.5 text-sm group">
            <span className="text-black/60 dark:text-white/60 font-medium ml-1 transition-colors group-focus-within:text-primary">Pickup date</span>
            <input
              type="date"
              value={pickupDate}
              onChange={(e) => setPickupDate(e.target.value)}
              className="h-12 rounded-xl bg-black/5 dark:bg-white/5 px-4 outline-none border border-transparent transition-all focus:border-primary/50 focus:bg-white dark:focus:bg-black/50 focus:ring-4 focus:ring-primary/10"
            />
          </label>

          <label className="grid gap-1.5 text-sm group">
            <span className="text-black/60 dark:text-white/60 font-medium ml-1 transition-colors group-focus-within:text-primary">Return date</span>
            <input
              type="date"
              value={returnDate}
              onChange={(e) => setReturnDate(e.target.value)}
              className="h-12 rounded-xl bg-black/5 dark:bg-white/5 px-4 outline-none border border-transparent transition-all focus:border-primary/50 focus:bg-white dark:focus:bg-black/50 focus:ring-4 focus:ring-primary/10"
            />
          </label>

          <label className="grid gap-1.5 text-sm group">
            <span className="text-black/60 dark:text-white/60 font-medium ml-1 transition-colors group-focus-within:text-primary">With driver</span>
            <select
              value={withDriver}
              onChange={(e) => setWithDriver(e.target.value as "Yes" | "No")}
              className="h-12 rounded-xl bg-black/5 dark:bg-white/5 px-4 outline-none border border-transparent transition-all focus:border-primary/50 focus:bg-white dark:focus:bg-black/50 focus:ring-4 focus:ring-primary/10 appearance-none cursor-pointer"
            >
              <option value="No">No</option>
              <option value="Yes">Yes</option>
            </select>
          </label>

          <label className="grid gap-1.5 text-sm md:col-span-2 group">
            <span className="text-black/60 dark:text-white/60 font-medium ml-1 transition-colors group-focus-within:text-primary">Notes</span>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={4}
              placeholder="Airport pickup, destination, preferred time, etc."
              className="resize-y rounded-xl bg-black/5 dark:bg-white/5 px-4 py-3 outline-none border border-transparent transition-all focus:border-primary/50 focus:bg-white dark:focus:bg-black/50 focus:ring-4 focus:ring-primary/10"
            />
          </label>
        </div>

        <div className="rounded-2xl border border-primary/20 bg-primary/5 p-4 mt-2">
          <div className="font-bold text-primary flex items-center gap-2">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-primary"></span>
            </span>
            What happens next?
          </div>
          <div className="mt-2 text-sm text-black/70 dark:text-white/70 font-medium leading-relaxed">
            Tap WhatsApp to send the booking request directly to our team. We’ll confirm availability and share the final PKR quote within minutes.
          </div>
        </div>

        <div className="flex flex-col gap-3 sm:flex-row mt-4">
          <a
            href={whatsappHref}
            target="_blank"
            rel="noreferrer"
            className="inline-flex h-14 flex-1 items-center justify-center rounded-full bg-[#25D366] px-6 text-base font-bold text-white shadow-lg shadow-[#25D366]/20 transition-all hover:scale-[1.02] hover:shadow-[#25D366]/40"
          >
            Send via WhatsApp
          </a>
          <a
            href={`tel:${site.supportPhone}`}
            className="inline-flex h-14 items-center justify-center rounded-full bg-black/5 dark:bg-white/5 px-8 text-base font-bold text-foreground transition-all hover:bg-black/10 dark:hover:bg-white/10"
          >
            Call instead
          </a>
        </div>
      </div>
    </div>
  );
}
