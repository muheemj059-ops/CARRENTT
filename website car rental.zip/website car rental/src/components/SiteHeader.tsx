import Link from "next/link";
import { site } from "@/lib/site";

const nav = [
  { href: "/fleet", label: "Fleet" },
  { href: "/book", label: "Book" },
  { href: "/contact", label: "Contact" },
] as const;

export function SiteHeader() {
  return (
    <div className="fixed top-0 left-0 right-0 z-50 p-4 animate-fade-in-up">
      <header className="mx-auto w-full max-w-5xl rounded-full glass-panel shadow-lg dark:shadow-black/50 transition-all duration-300">
        <div className="flex items-center justify-between gap-4 px-6 py-3">
          <Link href="/" className="flex items-center gap-3 group">
            <div className="grid h-10 w-10 place-items-center rounded-full bg-gradient-to-br from-emerald-400 to-cyan-500 text-white shadow-md transition-transform group-hover:scale-105">
              <span className="font-bold tracking-tight">PR</span>
            </div>
            <div className="leading-tight">
              <div className="text-sm font-bold tracking-tight text-foreground transition-colors group-hover:text-primary">
                {site.name}
              </div>
              <div className="text-xs text-black/50 dark:text-white/50 font-medium">
                {site.tagline}
              </div>
            </div>
          </Link>

          <nav className="hidden items-center gap-8 text-sm md:flex font-medium">
            {nav.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="relative text-black/60 dark:text-white/60 hover:text-foreground dark:hover:text-white transition-colors
                           after:absolute after:-bottom-1 after:left-0 after:h-[2px] after:w-0 after:bg-primary after:transition-all hover:after:w-full"
              >
                {item.label}
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-3">
            <Link
              href="/book"
              className="inline-flex h-10 items-center justify-center rounded-full bg-foreground px-5 text-sm font-semibold text-background shadow-lg shadow-black/10 transition-all hover:scale-105 hover:bg-primary dark:shadow-none hover:shadow-primary/30"
            >
              Request booking
            </Link>
          </div>
        </div>
      </header>
    </div>
  );
}
