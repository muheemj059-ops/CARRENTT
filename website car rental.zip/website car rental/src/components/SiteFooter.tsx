import Link from "next/link";
import { site } from "@/lib/site";

export function SiteFooter() {
  return (
    <footer className="relative mt-20 border-t border-black/5 dark:border-white/10 bg-white/50 dark:bg-[#080808]/50 pt-16 pb-8 backdrop-blur-md">
      <div className="absolute inset-x-0 -top-px h-px bg-gradient-to-r from-transparent via-primary/50 to-transparent" />
      <div className="mx-auto w-full max-w-6xl px-6">
        <div className="grid gap-10 md:grid-cols-4">
          <div className="space-y-4 md:col-span-2">
            <Link href="/" className="inline-block group">
              <div className="text-xl font-bold tracking-tight text-gradient transition-opacity group-hover:opacity-80">
                {site.name}
              </div>
            </Link>
            <p className="max-w-xs text-sm text-black/60 dark:text-white/60 leading-relaxed">
              {site.tagline} {site.addressLine}
            </p>
            <div className="space-y-1 pt-2">
              <div className="text-sm font-medium text-black/80 dark:text-white/80">
                <a
                  href={`tel:${site.supportPhone}`}
                  className="hover:text-primary transition-colors flex items-center gap-2"
                >
                  <span className="text-black/40 dark:text-white/40">Tel:</span>
                  {site.supportPhone}
                </a>
              </div>
              <div className="text-sm font-medium text-black/80 dark:text-white/80">
                <a
                  href={`mailto:${site.email}`}
                  className="hover:text-primary transition-colors flex items-center gap-2"
                >
                  <span className="text-black/40 dark:text-white/40">Email:</span>
                  {site.email}
                </a>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div className="text-sm font-semibold tracking-wide text-foreground">Quick links</div>
            <div className="flex flex-col gap-3 text-sm font-medium text-black/60 dark:text-white/60">
              <Link className="hover:text-primary transition-colors w-fit" href="/fleet">
                Fleet & rates
              </Link>
              <Link className="hover:text-primary transition-colors w-fit" href="/book">
                Booking request
              </Link>
              <Link className="hover:text-primary transition-colors w-fit" href="/contact">
                Contact us
              </Link>
            </div>
          </div>

          <div className="space-y-4">
            <div className="text-sm font-semibold tracking-wide text-foreground">Service cities</div>
            <div className="flex flex-wrap gap-2">
              {site.cities.map((c) => (
                <span
                  key={c}
                  className="rounded-full bg-black/5 dark:bg-white/5 px-3 py-1 text-xs font-medium text-black/70 dark:text-white/70 transition-colors hover:bg-black/10 dark:hover:bg-white/10"
                >
                  {c}
                </span>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-16 flex flex-col gap-4 border-t border-black/5 dark:border-white/10 pt-8 text-xs font-medium text-black/50 dark:text-white/50 md:flex-row md:items-center md:justify-between">
          <div>© {new Date().getFullYear()} {site.name}. All rights reserved.</div>
          <div className="max-w-md text-right">
            Pricing is indicative; final quote depends on dates, city, and availability.
          </div>
        </div>
      </div>
    </footer>
  );
}
