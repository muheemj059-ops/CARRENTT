import Link from "next/link";
import Image from "next/image";
import { Car } from "@/lib/cars";
import { formatPKR } from "@/lib/site";

export function CarCard({ car }: { car: Car }) {
  return (
    <Link
      href={`/cars/${car.slug}`}
      className="group relative flex flex-col overflow-hidden rounded-3xl glass-panel p-1.5 transition-all duration-500 hover:-translate-y-2 hover:shadow-2xl hover:shadow-primary/20"
    >
      <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/5 dark:to-white/5 opacity-0 transition-opacity duration-500 group-hover:opacity-100" />
      
      <div className="relative overflow-hidden rounded-[1.25rem] bg-white dark:bg-black/40">
        <div className="relative aspect-[16/10] w-full bg-gradient-to-br from-black/5 to-transparent dark:from-white/5">
          <Image
            src={car.imageSrc}
            alt={car.imageAlt}
            fill
            className="object-contain p-6 transition-transform duration-700 ease-out group-hover:scale-110 drop-shadow-xl"
          />
        </div>
        <div className="absolute top-3 left-3 rounded-full bg-white/90 dark:bg-black/80 backdrop-blur px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-primary shadow-sm">
          {car.category}
        </div>
      </div>

      <div className="relative flex flex-col flex-1 p-4">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h3 className="text-lg font-bold tracking-tight text-foreground transition-colors group-hover:text-primary">
              {car.name}
            </h3>
            <div className="mt-1.5 flex flex-wrap items-center gap-x-2 gap-y-1 text-xs font-medium text-black/60 dark:text-white/60">
              <span className="flex items-center gap-1">
                {car.ac ? "AC" : "No AC"}
              </span>
              <span className="h-1 w-1 rounded-full bg-black/20 dark:bg-white/20" />
              <span>{car.transmission}</span>
              <span className="h-1 w-1 rounded-full bg-black/20 dark:bg-white/20" />
              <span>{car.seats} seats</span>
              <span className="h-1 w-1 rounded-full bg-black/20 dark:bg-white/20" />
              <span>{car.fuel}</span>
            </div>
          </div>
        </div>

        <div className="mt-5 flex flex-wrap gap-1.5">
          {car.cityAvailability.slice(0, 3).map((c) => (
            <span
              key={c}
              className="rounded-md bg-black/5 dark:bg-white/10 px-2 py-1 text-[10px] font-semibold tracking-wide text-black/70 dark:text-white/70"
            >
              {c}
            </span>
          ))}
          {car.cityAvailability.length > 3 ? (
            <span className="rounded-md bg-black/5 dark:bg-white/10 px-2 py-1 text-[10px] font-semibold tracking-wide text-black/50 dark:text-white/50">
              +{car.cityAvailability.length - 3}
            </span>
          ) : null}
        </div>

        <div className="mt-auto pt-6 flex items-end justify-between">
          <div className="text-sm font-semibold tracking-tight text-primary opacity-0 -translate-x-2 transition-all duration-300 group-hover:opacity-100 group-hover:translate-x-0">
            View details →
          </div>
          <div className="text-right">
            <div className="text-[10px] font-semibold uppercase tracking-wider text-black/50 dark:text-white/50">
              From / day
            </div>
            <div className="text-lg font-black tracking-tighter text-foreground">
              {formatPKR(car.dailyFromPKR)}
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
}
