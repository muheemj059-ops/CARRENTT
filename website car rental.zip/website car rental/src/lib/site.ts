export const site = {
  name: "PakRide Car Rentals",
  tagline: "Reliable car rentals across Pakistan",
  supportPhone: "+92 300 1234567",
  whatsappNumberE164: "+923001234567",
  email: "bookings@pakride.example",
  cities: [
    "Karachi",
    "Lahore",
    "Islamabad",
    "Rawalpindi",
    "Faisalabad",
    "Multan",
    "Peshawar",
    "Quetta",
    "Sialkot",
    "Gujranwala",
  ] as const,
  addressLine: "Pickup available in major cities (Pakistan)",
} as const;

export function formatPKR(amount: number) {
  return new Intl.NumberFormat("en-PK", {
    style: "currency",
    currency: "PKR",
    maximumFractionDigits: 0,
  }).format(amount);
}

export function buildWhatsAppLink(message: string) {
  const phone = site.whatsappNumberE164.replace(/[^\d]/g, "");
  const url = new URL("https://wa.me/" + phone);
  url.searchParams.set("text", message);
  return url.toString();
}

